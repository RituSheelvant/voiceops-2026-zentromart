"""VoiceOps application source."""
